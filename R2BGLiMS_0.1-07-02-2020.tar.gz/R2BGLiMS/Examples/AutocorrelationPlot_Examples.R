library(R2BGLiMS)

### --- Logistic regression with two model space prior components
# Load results from the biopsy logistic regression analysis (see R2MHRJ examples)
data(biopsyResults)
AutocorrelationPlot(biopsyResults)
